from django.shortcuts import render

from . import models
def Empty(request):
    return render(request, 'about.html')
def Data(request):
    name = request.GET['name']

    phone = request.GET['phone']

    # if len(str(phone))==10 and (6000000000<phone<9999999999):
    #     pass
    # else:
    #     phone = int(input("enter valid phone:"))

    email=request.GET['email']
    if "@" in email:
        pass
    # else:
    #     email = input("enter valid emailid:")

    Branch=request.GET['branch']

    if Branch == "QSP":
        obj1=models.QSP()
        records=models.QSP.objects.all()
        obj1.NAME=name
        obj1.PHONE=phone
        obj1.EMAIL=email
        obj1.BRANCH=Branch
        obj1.save()

    # return render(request, 'index.html', context={'Branch':branch})

    elif Branch == "JSP":
        obj2=models.JSP()
        records=models.JSP.objects.all()
        obj2.NAME=name
        obj2.PHONE=phone
        obj2.EMAIL=email
        obj2.BRANCH=Branch
        obj2.save()
    # return render(request, 'index.html', context={'Branch':branch}) 
    else:
        obj3=models.PYSP()
        records=models.PYSP.objects.all()
        obj3.NAME=name
        obj3.PHONE=phone
        obj3.EMAIL=email
        obj3.BRANCH=Branch
        obj3.save()

    return render(request, 'about.html', context={'data':records})

def Display_DataQSP(request):
        records=models.JSP.objects.all()
        return render(request, 'about.html', context={'data':records})
def Display_DataJSP(request):
        records=models.QSP.objects.all()
        return render(request, 'about.html', context={'data':records})
def Display_DataPYSP(request):
        records=models.PYSP.objects.all()
        return render(request, 'about.html', context={'data':records})

# def App3_Response(request):
#     return HttpResponse("<h1>app3 respose were created</h1>")
# def Home(request):
#     return render(request,'index.html')

# def Profile(request):
#     My_name=input("enter the name:")
#     My_dob=input("enter the D.O.B:")
#     My_email=input("enter the email:")
#     My_degree=input("enter the degree:")
#     My_strem=input("enter the strem:")
#     My_gender=input("enter the gender:")
#     My_state=input("enter the state:")
#     My_city=input("enter the city:")
#     My_phone=input("enter the ph.np:")
#     return render(request,'profile.html',context={'name':My_name,'DOB':My_dob,'email':My_email,'degree':My_degree,'strem':My_strem,'gender':My_gender,'state':My_state,'city':My_city,'ph.no':My_phone})

# def About(request):
#     return render(request,'about.html')

# def login(request):
#     return render(request,'login.html')