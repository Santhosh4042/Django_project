from django.db import models

# Create your models here.
# class EMP(models.Model):
#     EMP_NO=models.CharField(max_length=100)
#     EMP_NAME=models.CharField(max_length=100)
#     EMP_SAL=models.CharField(max_length=100)

class QSP(models.Model):
    NAME=models.CharField(max_length=20)
    PHONE=models.IntegerField(max_length=20)
    EMAIL=models.CharField(max_length=20)
    BRANCH=models.CharField(max_length=5)

class JSP(models.Model):
    NAME=models.CharField(max_length=20)
    PHONE=models.IntegerField(max_length=20)
    EMAIL=models.CharField(max_length=20)
    BRANCH=models.CharField(max_length=5)

class PYSP(models.Model):
    NAME=models.CharField(max_length=20)
    PHONE=models.IntegerField(max_length=20)
    EMAIL=models.CharField(max_length=20)
    BRANCH=models.CharField(max_length=5)

