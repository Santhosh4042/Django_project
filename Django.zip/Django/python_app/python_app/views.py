from django.shortcuts import render, HttpResponse

def image(request):
    return HttpResponse("<h1>First respose were created</h1>")

def mes_res(request):
    return HttpResponse("<h1>second respose were created</h1>")

def third_res(request):
    return HttpResponse("<h1>third respose were created</h1>")