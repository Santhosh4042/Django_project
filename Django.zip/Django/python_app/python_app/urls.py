"""
URL configuration for python_app project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
# from . import views
#from application1 import views as vs1
from application2 import views as vs2
#from application3 import views as vs3

urlpatterns = [
    path('admin/', admin.site.urls),
    # path('First_Requst',views.First_Response),
    # path('scd_rq',views.mes_res),
    # path('td_rq',views.third_res),
    #path('login',vs1.login),
    # path('app2_rq',vs2.App2_Response),
    # path('app3_rq',vs3.App3_Response),
    # path('home',views.Home),
    # path('mydata',views.Profile),
    # path('loginpage',views.login)
    path('', vs2.Data_Entry),
    #path('Insertdata',vs2.Insert_Data),
    path('fetch_data',vs2.Fetch_Data),
    #path('',vs3.Empty),
    path('data', vs2.Insert_Data),
    path('update-<int:id>', vs2.Update_Data),
    path('delete-<int:id>', vs2.Delete_Records)
    #path('data', vs3.Data),
    #path('qsp_data', vs3.Display_DataQSP),
    #path('jsp_data', vs3.Display_DataJSP),
    #path('pysp_data', vs3.Display_DataPYSP),
    # path('img', vs1.image)
]

