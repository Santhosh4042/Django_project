from django.shortcuts import render


# Create your views here.

def image(request):
    return render(request,"image.html")

def login(request): 
    return render(request, "login.html")
